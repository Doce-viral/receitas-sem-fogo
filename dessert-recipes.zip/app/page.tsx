"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CategoryCard } from "@/components/category-card"
import { RecipeCard } from "@/components/recipe-card"
import { BottomNav } from "@/components/bottom-nav"
import { TrendingWidget } from "@/components/trending-widget"
import { categories } from "@/data/categories"
import { recipes } from "@/data/recipes"
import { getCompletedRecipes } from "@/lib/storage"
import { Flame, ChefHat, TrendingUp } from "lucide-react"

export default function HomePage() {
  const [completedRecipes, setCompletedRecipes] = useState<string[]>([])

  useEffect(() => {
    setCompletedRecipes(getCompletedRecipes())
  }, [])

  const featuredRecipes = [
    recipes.find((r) => r.id === "brigadeiro-cremoso"),
    recipes.find((r) => r.id === "banoffee"),
    recipes.find((r) => r.id === "mousse-maracuja"),
  ].filter(Boolean) as typeof recipes

  return (
    <div className="min-h-screen bg-background" style={{ paddingBottom: "88px" }}>
      <div className="relative overflow-hidden bg-gradient-to-b from-black via-zinc-950 to-background">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(251,191,36,0.12),transparent_60%)]" />
        <div className="relative max-w-md mx-auto px-5 pt-12 pb-16">
          <div className="text-center space-y-5">
            <h1 className="text-4xl sm:text-5xl font-bold text-balance leading-[1.1] tracking-tight px-4">
              Receitas Sem Fogo
            </h1>
            <p className="text-base sm:text-lg text-muted-foreground/90 text-balance max-w-sm mx-auto leading-relaxed px-4">
              Sobremesas sem complicação — para vender ou fazer em casa.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
              <Badge
                variant="outline"
                className="border-primary/40 text-primary bg-primary/5 px-3 py-1.5 whitespace-nowrap"
              >
                <Flame className="w-3.5 h-3.5 mr-1.5 flex-shrink-0" />
                Sem fogão
              </Badge>
              <Badge
                variant="outline"
                className="border-primary/40 text-primary bg-primary/5 px-3 py-1.5 whitespace-nowrap"
              >
                <ChefHat className="w-3.5 h-3.5 mr-1.5 flex-shrink-0" />
                Fácil
              </Badge>
              <Badge
                variant="outline"
                className="border-primary/40 text-primary bg-primary/5 px-3 py-1.5 whitespace-nowrap"
              >
                <TrendingUp className="w-3.5 h-3.5 mr-1.5 flex-shrink-0" />
                Para vender
              </Badge>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto px-5 -mt-8 mb-6">
        <TrendingWidget />
      </div>

      <div className="max-w-md mx-auto px-5 py-6 space-y-6">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-2xl font-bold">Categorias</h2>
          <Link href="/categorias">
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 min-h-[44px]">
              Ver todas
            </Button>
          </Link>
        </div>
        <div className="grid gap-4">
          {categories.map((category) => {
            const categoryRecipes = recipes.filter((r) => r.categoryId === category.id)
            const completedCount = categoryRecipes.filter((r) => completedRecipes.includes(r.id)).length

            return (
              <CategoryCard
                key={category.id}
                id={category.id}
                name={category.name}
                description={category.description}
                totalRecipes={category.totalRecipes}
                completedCount={completedCount}
              />
            )
          })}
        </div>
      </div>

      <div className="max-w-md mx-auto px-5 py-6 space-y-6">
        <h2 className="text-2xl font-bold">Destaques</h2>
        <div className="grid gap-4">
          {featuredRecipes.map((recipe) => (
            <RecipeCard
              key={recipe.id}
              id={recipe.id}
              name={recipe.name}
              description={recipe.description}
              time={recipe.time}
              servings={recipe.servings}
            />
          ))}
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
