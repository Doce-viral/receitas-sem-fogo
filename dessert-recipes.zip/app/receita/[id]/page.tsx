"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { BottomNav } from "@/components/bottom-nav"
import { ModeToggle, useMode } from "@/components/mode-toggle"
import { TimerCompleteModal } from "@/components/timer-complete-modal"
import { recipes } from "@/data/recipes"
import { categories } from "@/data/categories"
import {
  toggleRecipeFavorite,
  getFavoriteRecipes,
  getStepProgress,
  toggleStepCompletion,
  clearStepProgress,
} from "@/lib/storage"
import { scaleIngredients } from "@/lib/scaling"
import {
  startTimer,
  getActiveTimers,
  removeTimer,
  getRemainingTime,
  formatTime,
  playAlarm,
  stopAlarm,
  vibrateDevice,
  requestNotificationPermission,
  sendTimerNotification,
} from "@/lib/timers"
import { downloadTextFile, generateShoppingList } from "@/lib/download"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, Clock, Users, Heart, CheckCircle2, Timer, Copy, Package2, Download } from "lucide-react"
import { cn } from "@/lib/utils"

export default function RecipePage() {
  const params = useParams()
  const router = useRouter()
  const recipeId = params.id as string
  const { toast } = useToast()
  const { mode } = useMode()

  const [isFavorite, setIsFavorite] = useState(false)
  const [completedSteps, setCompletedSteps] = useState<number[]>([])
  const [productionUnits, setProductionUnits] = useState<number>(1)
  const [activeTimer, setActiveTimer] = useState<ReturnType<typeof getActiveTimers>[0] | null>(null)
  const [remainingTime, setRemainingTime] = useState(0)
  const [showTimerCompleteModal, setShowTimerCompleteModal] = useState(false)

  const recipe = recipes.find((r) => r.id === recipeId)
  const category = recipe ? categories.find((c) => c.id === recipe.categoryId) : null

  useEffect(() => {
    setIsFavorite(getFavoriteRecipes().includes(recipeId))
    setCompletedSteps(getStepProgress(recipeId))

    const timers = getActiveTimers()
    const recipeTimer = timers.find((t) => t.recipeId === recipeId)
    if (recipeTimer) {
      setActiveTimer(recipeTimer)
    }
  }, [recipeId])

  useEffect(() => {
    if (!activeTimer) return

    const interval = setInterval(() => {
      const remaining = getRemainingTime(activeTimer)
      setRemainingTime(remaining)

      if (remaining === 0) {
        removeTimer(activeTimer.id)
        setActiveTimer(null)
        playAlarm()
        vibrateDevice()
        sendTimerNotification(activeTimer.recipeName)
        setShowTimerCompleteModal(true)
        toast({
          title: "Timer finalizado!",
          description: `${activeTimer.label} está pronto!`,
        })
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [activeTimer, toast])

  if (!recipe || !category) {
    return <div>Receita não encontrada</div>
  }

  const scaledIngredients =
    mode === "production" ? scaleIngredients(recipe.ingredients, recipe.servings, productionUnits) : null

  const completionPercentage = Math.round((completedSteps.length / recipe.instructions.length) * 100)

  const handleToggleFavorite = () => {
    toggleRecipeFavorite(recipeId)
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removido dos favoritos" : "Adicionado aos favoritos",
      description: isFavorite ? "Receita removida" : "Receita salva com sucesso!",
    })
  }

  const handleToggleStep = (stepIndex: number) => {
    toggleStepCompletion(recipeId, stepIndex)
    const newCompleted = getStepProgress(recipeId)
    setCompletedSteps(newCompleted)

    if (newCompleted.length === recipe.instructions.length) {
      toast({
        title: "Parabéns! Receita concluída!",
        description: "Você completou todos os passos desta receita.",
      })
    }
  }

  const handleResetProgress = () => {
    clearStepProgress(recipeId)
    setCompletedSteps([])
    toast({
      title: "Progresso reiniciado",
      description: "Você pode começar novamente.",
    })
  }

  const handleStartTimer = async () => {
    if (!recipe.chillTime) return

    await requestNotificationPermission()

    const timer = startTimer(recipeId, recipe.name, recipe.chillTime, `Tempo de geladeira: ${recipe.chillTime} min`)
    setActiveTimer(timer)
    setRemainingTime(recipe.chillTime * 60)

    toast({
      title: "Temporizador iniciado!",
      description: `${recipe.chillTime} minutos`,
    })
  }

  const handleCopySalesText = () => {
    const salesText = recipe.salesDescription || `${recipe.name} - ${recipe.description}`
    navigator.clipboard.writeText(salesText)

    toast({
      title: "Texto copiado!",
      description: "Texto para venda copiado para área de transferência",
    })
  }

  const handleDownloadShoppingList = () => {
    if (!productionUnits || productionUnits < 1) {
      toast({
        title: "Defina a quantidade para produção",
        description: "Insira quantas unidades deseja produzir",
        variant: "destructive",
      })
      return
    }

    if (!scaledIngredients) {
      toast({
        title: "Erro ao gerar lista",
        description: "Não foi possível calcular os ingredientes",
        variant: "destructive",
      })
      return
    }

    const { filename, content } = generateShoppingList(recipe.name, recipe.id, productionUnits, scaledIngredients)

    downloadTextFile(filename, content)

    toast({
      title: "Lista de compras baixada!",
      description: `${filename} salvo no seu dispositivo`,
    })
  }

  const handleStopAlarm = () => {
    stopAlarm()
    setShowTimerCompleteModal(false)
  }

  const handleRestartTimer = () => {
    stopAlarm()
    setShowTimerCompleteModal(false)
    handleStartTimer()
  }

  const handleCloseModal = () => {
    stopAlarm()
    setShowTimerCompleteModal(false)
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="relative h-64 bg-gradient-to-br from-primary/20 to-primary/5">
        <Image
          src={recipe.imageUrl || "/placeholder.svg"}
          alt={recipe.name}
          fill
          className="object-cover"
          onError={(e) => {
            const target = e.target as HTMLImageElement
            target.src = "/images/placeholder.jpg"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        <Link href={`/categoria/${recipe.categoryId}`}>
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 left-4 rounded-full bg-card/80 backdrop-blur-sm"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            "absolute top-4 right-4 rounded-full bg-card/80 backdrop-blur-sm",
            isFavorite && "text-red-500",
          )}
          onClick={handleToggleFavorite}
        >
          <Heart className={cn("w-5 h-5", isFavorite && "fill-current")} />
        </Button>
      </div>

      <div className="max-w-md mx-auto px-6 -mt-8 space-y-6">
        <Card className="p-6 space-y-4 border-border/50">
          <div>
            <Badge variant="secondary" className="mb-2 bg-primary/10 text-primary border-primary/20">
              {category.name}
            </Badge>
            <h1 className="text-3xl font-bold text-balance">{recipe.name}</h1>
            <p className="text-muted-foreground mt-2">{recipe.description}</p>
          </div>

          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              <span>{recipe.time}</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              <span>{recipe.servings} porções</span>
            </div>
          </div>

          <div className="pt-2">
            <ModeToggle />
          </div>
        </Card>

        {mode === "production" && (
          <Card className="p-6 space-y-4 border-border/50 bg-gradient-to-br from-primary/5 to-transparent">
            <div className="flex items-center gap-2 text-primary">
              <Package2 className="w-5 h-5" />
              <h2 className="text-lg font-bold">Modo Produção</h2>
            </div>

            <div className="space-y-2">
              <Label htmlFor="units">Quantas unidades deseja produzir?</Label>
              <Input
                id="units"
                type="number"
                min="1"
                value={productionUnits}
                onChange={(e) => setProductionUnits(Number(e.target.value) || 1)}
                className="h-12 text-lg"
              />
              <p className="text-xs text-muted-foreground">
                Receita original: {recipe.servings} {recipe.servings === 1 ? "porção" : "porções"}
              </p>
            </div>

            <Button
              onClick={handleDownloadShoppingList}
              className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Download className="w-4 h-4 mr-2" />
              LISTA DE COMPRAS
            </Button>
          </Card>
        )}

        <Card className="p-6 space-y-4 border-border/50">
          <h2 className="text-xl font-bold">Ingredientes</h2>
          {mode === "production" && productionUnits !== recipe.servings && (
            <p className="text-sm text-primary font-medium">
              Quantidades ajustadas para {productionUnits} {productionUnits === 1 ? "porção" : "porções"}
            </p>
          )}
          <ul className="space-y-3">
            {(mode === "production" && scaledIngredients
              ? scaledIngredients
              : recipe.ingredients.map((i) => ({ scaled: i }))
            ).map((ingredient, index) => (
              <li key={index} className="flex items-start gap-3 text-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                <span className="text-foreground">{ingredient.scaled}</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="p-6 space-y-4 border-border/50">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">Modo de preparo</h2>
            {completedSteps.length > 0 && (
              <Button variant="ghost" size="sm" onClick={handleResetProgress}>
                Reiniciar
              </Button>
            )}
          </div>

          {completedSteps.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Progresso</span>
                <span className="font-semibold text-primary">{completionPercentage}%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>
            </div>
          )}

          <ol className="space-y-4">
            {recipe.instructions.map((instruction, index) => {
              const isCompleted = completedSteps.includes(index)
              return (
                <li key={index} className="flex gap-4">
                  <div className="flex items-start gap-3 flex-1">
                    <Checkbox
                      id={`step-${index}`}
                      checked={isCompleted}
                      onCheckedChange={() => handleToggleStep(index)}
                      className="mt-1"
                    />
                    <label
                      htmlFor={`step-${index}`}
                      className={cn(
                        "text-sm leading-relaxed cursor-pointer flex-1",
                        isCompleted && "line-through text-muted-foreground",
                      )}
                    >
                      <span className="font-semibold text-primary mr-2">Passo {index + 1}:</span>
                      {instruction}
                    </label>
                  </div>
                </li>
              )
            })}
          </ol>

          {completedSteps.length === recipe.instructions.length && (
            <div className="flex items-center gap-2 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              <span className="text-sm font-medium text-green-500">Receita concluída!</span>
            </div>
          )}
        </Card>

        {recipe.chillTime && (
          <Card className="p-6 space-y-4 border-border/50">
            <div className="flex items-center gap-2">
              <Timer className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">Temporizador de Geladeira</h2>
            </div>

            {activeTimer ? (
              <div className="space-y-3">
                <div className="text-center">
                  <div className="text-4xl font-bold text-primary">{formatTime(remainingTime)}</div>
                  <p className="text-sm text-muted-foreground mt-1">{activeTimer.label}</p>
                </div>
                <Button
                  variant="outline"
                  className="w-full bg-transparent"
                  onClick={() => {
                    removeTimer(activeTimer.id)
                    setActiveTimer(null)
                    toast({ title: "Temporizador cancelado" })
                  }}
                >
                  Cancelar Temporizador
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Tempo recomendado: {recipe.chillTime} minutos na geladeira
                </p>
                <Button onClick={handleStartTimer} className="w-full">
                  <Timer className="w-4 h-4 mr-2" />
                  Iniciar Temporizador
                </Button>
              </div>
            )}
          </Card>
        )}

        {mode === "production" && (
          <Card className="p-6 space-y-4 border-border/50 bg-gradient-to-br from-primary/5 to-transparent">
            <h2 className="text-xl font-bold">Para Vender</h2>

            {recipe.shelfLife && (
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Validade</p>
                <p className="text-sm">{recipe.shelfLife}</p>
              </div>
            )}

            {recipe.packaging && (
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Embalagem sugerida</p>
                <p className="text-sm capitalize">{recipe.packaging}</p>
              </div>
            )}

            {recipe.salesDescription && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Descrição para venda</p>
                <div className="p-3 bg-card rounded-lg border border-border/50">
                  <p className="text-sm">{recipe.salesDescription}</p>
                </div>
                <Button variant="outline" size="sm" onClick={handleCopySalesText} className="w-full bg-transparent">
                  <Copy className="w-4 h-4 mr-2" />
                  Copiar texto
                </Button>
              </div>
            )}
          </Card>
        )}

        <Card className="p-6 space-y-4 border-border/50 bg-gradient-to-br from-primary/5 to-transparent">
          <h2 className="text-xl font-bold">Dicas {mode === "production" ? "para vender" : ""}</h2>
          <ul className="space-y-3">
            {recipe.tips.map((tip, index) => (
              <li key={index} className="flex items-start gap-3 text-sm">
                <span className="text-primary text-lg flex-shrink-0">💡</span>
                <span className="text-foreground">{tip}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <BottomNav />

      <TimerCompleteModal
        isOpen={showTimerCompleteModal}
        recipeName={recipe.name}
        onStopAlarm={handleStopAlarm}
        onRestart={handleRestartTimer}
        onClose={handleCloseModal}
      />
    </div>
  )
}
